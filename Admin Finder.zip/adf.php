<?php
/**
	[PHP-CLI] AdminFinder
	--
	Created by Sec7ion from BlackHoleSecurity
	Facebook: @Sec7ion
	Github:   @Sec7ion
*/

// Hide the Error
error_reporting(0);

// Word List
$wl = file_get_contents("wordlist.txt");

class AdFinder {
  private
  // Color
  $Red   = "\e[1;31m",
  $Lime  = "\e[1;32m",
  $Blue  = "\e[1;34m",
  $White = "\e[1;37m",
  // Word List
  $WL;
  
  public function __construct(string $wl) {
    $this->WL = $wl;
    $this->Start();
  }
  
  //Start Finder
  public function Start() {
    $site = getopt("u:")["u"];
    if (isset($site) && !empty($site) && preg_match("/./", $site)) {
        // Clean Screen & Color
        $os = ucfirst(substr(PHP_OS, 0, 3));
        if ($os === "Win"):
          system("cls");
          $this->Red   = null;
          $this->Lime  = null;
          $this->Blue  = null;
          $this->White = null;
        else:
          system("clear");
        endif;
      
      if (!preg_match("/^https?:\/\//", $site)){
        $site = "http://{$site}";
      }
      if (!preg_match("/\/$/", $site)) {
        $site .= "/";
      }
      $WL = explode(PHP_EOL, $this->WL);
      $WC = count($WL);
      echo "{$this->Blue}Total Word List: {$this->White}{$WC}", PHP_EOL;
      for ($i = 0; $i < $WC; $i++) {
        $rest = "{$site}{$WL[$i]}";
        $headers = substr(get_headers($rest)[0], 9, 3);
        if ($headers == "200") {
          $result .= "{$this->White}{$rest}" . PHP_EOL;
          echo "{$this->Blue}[{$this->Lime}Got Found{$this->Blue}] >{$this->Lime}-{$this->Blue}> {$this->White}{$rest}", PHP_EOL;
          $next = strtolower(trim(readline("Ketemu Tu. Next? (Enter to Next) or (q to Quit): ")));
          ($next == "q") ? die("Bye~") : null;
        } else {
          echo "{$this->Blue}[{$this->Red}Not Found{$this->Blue}] >{$this->Red}-{$this->Blue}> {$this->White}{$rest}", PHP_EOL;
        }
      }
      echo PHP_EOL, "{$this->Lime}Total:", PHP_EOL, "{$result}";
    } else {
       die("Usage: " . basename(__FILE__) . " -u site.com" . PHP_EOL);
    }
  }
}
new AdFinder($wl);